import VictoryCustomTheme from "./VictoryCustomTheme";

export { VictoryCustomTheme }