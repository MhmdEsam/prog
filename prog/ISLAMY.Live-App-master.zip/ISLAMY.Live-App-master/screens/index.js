import Home from "./Home"
import More from "./More";
import Ramadan from "./Ramadan";
import Salah from "./Salah";
import Quran from "./Quran";
export {
    Home,
    More ,
     Ramadan ,
     Salah,
     Quran
};
