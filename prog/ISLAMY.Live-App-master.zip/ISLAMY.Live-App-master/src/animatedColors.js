export  const animatedColors ={
    custom:[
      'rgb(29, 137 , 47)' ,
      'rgb(14, 78 , 25)' ,
      'rgb(27, 213 , 58)',
      'rgb(39, 127 , 54)',
      'rgb(41, 243 , 0)',
      'rgb(20, 45 , 30)',
    ]
  }