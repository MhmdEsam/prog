# quraniquiz

##This is QuraniQuiz Project, it is meant to be a way to help my brothers in memorizing quran, but i think iit would be helpful for everybody

> you can here test your memorization about quran itself, or the ayat number surah names and so on
>> comleting the hardest one is very tough though because it includes the longest quran surahs, though with hard work every one can get there

!you would notice that i'm using python in some parts, but that was just for collecting data and optimizing it

//this project is free and open source for body to use

***abdulrahman azmy***
