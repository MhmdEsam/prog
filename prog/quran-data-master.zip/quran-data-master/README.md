<div dir="rtl">
يحتوي هذا المستودع على القرآن في ملفات نصية صِرفة بترميز يونيكود متبعا أفضل
ممارسات استخدام يونيكود قدر الإمكان (لا حيل خاصة بخط معين، و لا إعادة استخدام نقاط
ترميز في غير ما وضعت له، إلى غير ذلك)، بالإضافة إلى بعض الأدوات لتحويله إلا أنساق
أخرى.

بعد العلامات المستخدمة في هذا النص أضيفت إلى يونيكود في إصدارتها ٦٫١ لذا قد تظهر
مشكلات في عرض هذا النص في البرمجيات القديمة أو التي لم تُحدّث إلى آخر إصدارات من
يونيكود.

**لم يدقق هذا النص رسميًا بعد، و قد يحتوي على أخطاء، فالرجاء الإبلاغ عن أي أخطاء
تُكتشف.**

يظهر النص حاليا أنسب ما يكون مع خط [أميري قرآن][Amiri Quran]، إذ يحتوي على كل
العلامات المطلوبة و قواعد تنضيدها الصحيحة.

يعتمد هذه النص (و خط أميري قرآن) رسم مصحف الأزهر (المعروف أحيانًا بالمصحف الأميري،
أو مصحف مصلحة المساحة، أو مصحف الحفاظ، أو مصحف الاثني عشر سطرًا) في طبعته الرابعة
المطبوعة عام ١٣٨٨ ه‍.
</div>

This repository contains Quran as UTF-8 encoded plain text files, following the
best Unicode practices as possible (no more font specific hacks, no repurposing
of totally unrelated code points and so one), plus some tools to convert it
into other document formats.

Some of the symbols used in this text were introduced in Unicode 6.1, so old
applications or applications that haven’t been updated to Unicode 6.1 or newer
might have issues displaying this text.

**The text have not been formally reviewd, yet, so it may contain some errors.
If you find any please, please report it.**

Currently the text is best viewed using [Amiri Quran] font, as it has all the
needed symbols and layout rules.

[Amiri Quran]: http://www.amirifont.org
