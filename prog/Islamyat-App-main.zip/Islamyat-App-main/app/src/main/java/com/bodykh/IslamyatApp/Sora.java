package com.bodykh.IslamyatApp;

public class Sora {
    private String arsora;
    private String ensora;

    public Sora(String arsora, String ensora) {
        this.arsora = arsora;
        this.ensora = ensora;
    }

    public String getArsora() {
        return arsora;
    }

    public void setArsora(String arsora) {
        this.arsora = arsora;
    }

    public String getEnsora() {
        return ensora;
    }

    public void setEnsora(String ensora) {
        this.ensora = ensora;
    }
}
